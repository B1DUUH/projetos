function seleciona(x, y) {
	if (
	  (movimenta['selecionada']['x'] == 0 ||
		peca[x][y]['cor'] == movimenta['selecionada']['cor']) &&
	  peca[x][y]['cor'] == vez
	) {
	  if (movimenta['selecionada']['x'] != 0) {
		volta_fundo(); //volta a cor de fundo normal
	  }
	  if (peca[x][y]['peca']) {
		//se tiver uma peca nessa posição
		movimenta['selecionada']['x'] = x; //recebe x selecionado
		movimenta['selecionada']['y'] = y; //recebe y selecionado
		movimenta['selecionada']['peca'] = peca[x][y]['peca']; //recebe a peca selecionada
		movimenta['selecionada']['cor'] = peca[x][y]['cor']; //recebe a cor selecionada
  
		cont_possiveis = possiveis_movimentos();
	  }
	} else if (verifica_possivel(x, y, cont_possiveis)) {
	  //se for segundo clique e a cor da peca destino for diferente da selecionada
  
	  if (peca[x][y]['peca'] == 'rei') {
		alert(movimenta['selecionada']['cor'] + ' venceu (:');
		window.location.reload();
	  }
  
	  //Pra trocar de peça quando o peão chegar do outro lado
	  if (movimenta['selecionada']['peca'] == 'peao' && movimenta['selecionada']['cor'] == 'branco' && x == 1) {
		document.getElementById('escolhebranco').style.display = 'block';
		document.getElementById('fundo').style.display = 'block';
		xe = x;
		ye = y;
	  }
	  if (movimenta['selecionada']['peca'] == 'peao' && movimenta['selecionada']['cor'] == 'preto' && x == 8) {
		document.getElementById('escolhepreto').style.display = 'block';
		document.getElementById('fundo').style.display = 'block';
		xe = x;
		ye = y;
	  }
  
	  if (peca[x][y]['cor'] != movimenta['selecionada']['cor']) {
		movimenta['destino']['x'] = x; //recebe o x do destino(segundo clique)
		movimenta['destino']['y'] = y; //recebe y do destino(segundo clique)
  
		if (peca[x][y]['peca']) {
		  //se tiver alguma peca nessa posição
		  movimenta['destino']['peca'] = peca[x][y]['peca']; //destino recebe a peca selecionada
		  movimenta['destino']['cor'] = peca[x][y]['cor']; //destino recebe a cor selecionada
		}
  
		document.getElementById("t" + movimenta['selecionada']['x'] + "" + movimenta['selecionada']['y']).className =
		  ""; //selcionada fica sem imagem
		document.getElementById("t" + x + "" + y).className =
		  movimenta['selecionada']['peca'] + "-" + movimenta['selecionada']['cor']; //destino recebe a imagem da peça selecinada
		peca[x][y]['peca'] = movimenta['selecionada']['peca']; //posicao destino recebe a peca
		peca[x][y]['cor'] = movimenta['selecionada']['cor']; //posicao destino recebe a cor
  
		peca[movimenta['selecionada']['x']][movimenta['selecionada']['y']]['peca'] = false; //peca selecionada recebe 0
		peca[movimenta['selecionada']['x']][movimenta['selecionada']['y']]['cor'] = false; //cor selecionada recebe 0
  
		movimenta['selecionada']['x'] = 0; //selecionada x recebe 0 (pra na proxima ver q é o primeiro movimento)
		movimenta['selecionada']['y'] = 0; //selecionada y recebe 0 (pra na proxima ver q é o primeiro movimento)
		movimenta['selecionada']['peca'] = "0"; //selecionada peca recebe 0 (pra na proxima ver q é o primeiro movimento)
		movimenta['selecionada']['cor'] = "0"; //selecionada cor recebe 0 (pra na proxima ver q é o primeiro movimento)
	  }
  
	  volta_fundo(); //volta a cor de fundo normal
  
	  if (vez == "branco") {
		vez = "preto";
		// Peças brancas
		document.querySelectorAll('.peao-branco').forEach(function(peaoB) {
			peaoB.classList.add('rotate-chess');
		});
		document.querySelectorAll('.rainha-branco').forEach(function(rainhaB) {
			rainhaB.classList.add('rotate-chess');
		});
		document.querySelectorAll('.rei-branco').forEach(function(reiB) {
			reiB.classList.add('rotate-chess');
		});
		document.querySelectorAll('.torre-branco').forEach(function(torreB) {
			torreB.classList.add('rotate-chess');
		});
		document.querySelectorAll('.cavalo-branco').forEach(function(cavaloB) {
			cavaloB.classList.add('rotate-chess');
		});
		document.querySelectorAll('.bispo-branco').forEach(function(bispoB) {
			bispoB.classList.add('rotate-chess');
		});
		// Peças pretas
		document.querySelectorAll('.peao-preto').forEach(function(peaoP) {
			peaoP.classList.add('rotate-chess');
		});
		document.querySelectorAll('.rainha-preto').forEach(function(rainhaP) {
			rainhaP.classList.add('rotate-chess');
		});
		document.querySelectorAll('.rei-preto').forEach(function(reiP) {
			reiP.classList.add('rotate-chess');
		});
		document.querySelectorAll('.torre-preto').forEach(function(torreP) {
			torreP.classList.add('rotate-chess');
		});
		document.querySelectorAll('.cavalo-preto').forEach(function(cavaloP) {
			cavaloP.classList.add('rotate-chess');
		});
		document.querySelectorAll('.bispo-preto').forEach(function(bispoP) {
			bispoP.classList.add('rotate-chess');
		});
		document.getElementById('tabuleiro').classList.add('rotate-board');
		document.getElementById('tabuleiro').classList.remove('unrotate-board')
	  } else {
		vez = "branco";
		// Peças brancas
		document.querySelectorAll('.peao-branco').forEach(function(peaoB) {
			peaoB.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.rainha-branco').forEach(function(rainhaB) {
			rainhaB.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.rei-branco').forEach(function(reiB) {
			reiB.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.torre-branco').forEach(function(torreB) {
			torreB.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.cavalo-branco').forEach(function(cavaloB) {
			cavaloB.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.bispo-branco').forEach(function(bispoB) {
			bispoB.classList.remove('rotate-chess');
		});
		// Peças pretas
		document.querySelectorAll('.rainha-preto').forEach(function(rainhaP) {
			rainhaP.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.rei-preto').forEach(function(reiP) {
			reiP.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.torre-preto').forEach(function(torreP) {
			torreP.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.cavalo-preto').forEach(function(cavaloP) {
			cavaloP.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.bispo-preto').forEach(function(bispoP) {
			bispoP.classList.remove('rotate-chess');
		});
		document.querySelectorAll('.peao-preto').forEach(function(peaoP) {
			peaoP.classList.remove('rotate-chess');
		});
		// Adicione a classe de rotação após o movimento ser concluído
		document.getElementById('tabuleiro').classList.remove('rotate-board')
		document.getElementById('tabuleiro').classList.add('unrotate-board');;
	  } //troca a vez
	}
  }
  
  function escolhe(pecae, core) {
	peca[xe][ye]['peca'] = pecae;
	document.getElementById("t" + xe + "" + ye).className = pecae + "-" + core;
	document.getElementById('escolhe' + core).style.display = 'none';
	document.getElementById('fundo').style.display = 'none';
  }
  