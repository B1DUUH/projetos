let dealerSum = 0;
let yourSum = 0;

let dealerAceCount = 0;
let yourAceCount = 0;

let hidden;
let deck;

let canHit = true; // Permite ao jogador (você) comprar cartas enquanto yourSum for menor ou igual a 21

window.onload = function() {
    buildDeck(); // Cria um baralho de cartas
    shuffleDeck(); // Embaralha o baralho
    startGame(); // Inicia o jogo
}

function buildDeck() {
    // Define os valores e naipes das cartas
    let values = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
    let types = ["C", "D", "H", "S"];
    deck = [];

    // Cria um baralho completo, combinando valores e naipes
    for (let i = 0; i < types.length; i++) {
        for (let j = 0; j < values.length; j++) {
            deck.push(values[j] + "-" + types[i]);
        }
    }
}

function shuffleDeck() {
    // Embaralha o baralho trocando aleatoriamente as posições das cartas
    for (let i = 0; i < deck.length; i++) {
        let j = Math.floor(Math.random() * deck.length);
        let temp = deck[i];
        deck[i] = deck[j];
        deck[j] = temp;
    }
}

function startGame() {
    // Inicia o jogo, dando cartas iniciais ao jogador (você) e à banca (dealer)

    hidden = deck.pop(); // Tira uma carta do baralho para a carta escondida da banca
    dealerSum += getValue(hidden); // Adiciona o valor da carta escondida à soma da banca
    dealerAceCount += checkAce(hidden); // Verifica se a carta escondida é um Ás e a adiciona à contagem

    // Dá duas cartas iniciais ao jogador (você)
    for (let i = 0; i < 2; i++) {
        let cardImg = document.createElement("img");
        let card = deck.pop();
        cardImg.src = "./cards/" + card + ".png";
        yourSum += getValue(card);
        yourAceCount += checkAce(card);
        document.getElementById("your-cards").append(cardImg);
    }

    // Dá uma carta com o naipe para cima para o dealer
    let cardImg = document.createElement("img");
    let card = deck.pop();
    cardImg.src = "./cards/" + card + ".png";
    dealerSum += getValue(card);
    dealerAceCount += checkAce(card);
    document.getElementById("dealer-cards").append(cardImg);

    // Adiciona event listeners para os botões "Hit" e "Stay"
    document.getElementById("hit").addEventListener("click", hit);
    document.getElementById("stay").addEventListener("click", stay);
}

function hit() {
    // Função chamada quando o jogador (você) clica no botão "Hit" para comprar uma carta

    if (!canHit) {
        return; // Impede que o jogador compre mais cartas se não estiver permitido
    }

    let cardImg = document.createElement("img");
    let card = deck.pop();
    cardImg.src = "./cards/" + card + ".png";
    yourSum += getValue(card);
    yourAceCount += checkAce(card);
    document.getElementById("your-cards").append(cardImg);

    // Verifica se a compra de uma carta resultou em um valor maior que 21 para o jogador
    if (reduceAce(yourSum, yourAceCount) > 21) {
        canHit = false; // Impede que o jogador compre mais cartas
    }
}

function stay() {
    // Função chamada quando o jogador (você) clica no botão "Stay" para encerrar sua vez

    dealerSum = reduceAce(dealerSum, dealerAceCount);
    yourSum = reduceAce(yourSum, yourAceCount);

    canHit = false; // Impede que o jogador compre mais cartas

    document.getElementById("hidden").src = "./cards/" + hidden + ".png"; // Mostra a carta escondida da banca

    // Determina o resultado do jogo e exibe uma mensagem
    let message = "";
    if (yourSum > 21) {
        message = "perdeu!";
    } else if (dealerSum > 21) {
        message = "ganhou!";
    } else if (yourSum == dealerSum) {
        message = "empate!";
    } else if (yourSum > dealerSum) {
        message = "ganhou!";
    } else if (yourSum < dealerSum) {
        message = "perdeu!";
    }

    // Atualiza as informações na interface do jogo
    document.getElementById("dealer-sum").innerText = dealerSum;
    document.getElementById("your-sum").innerText = yourSum;
    document.getElementById("results").innerText = message;
}

function getValue(card) {
    // Obtém o valor da carta com base em seu nome
    let data = card.split("-");
    let value = data[0];

    if (isNaN(value)) { // Cartas especiais (A, J, Q, K)
        if (value == "A") {
            return 11;
        }
        return 10;
    }
    return parseInt(value);
}

function checkAce(card) {
    // Verifica se a carta é um Ás (A)
    if (card[0] == "A") {
        return 1;
    }
    return 0;
}

function reduceAce(playerSum, playerAceCount) {
    // Reduz o valor dos Áses (A) de 11 para 1, se necessário, para evitar estourar 21
    while (playerSum > 21 && playerAceCount > 0) {
        playerSum -= 10;
        playerAceCount -= 1;
    }
    return playerSum;
}
