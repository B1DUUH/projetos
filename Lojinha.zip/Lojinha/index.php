<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Lojinha Marotinha</title>
    <link rel="icon" href="media/icon.png">
</head>
<body>
    <div class="cab">
        <h1>Lojinha Marotinha</h1>
    </div>
    <div class="bg">
    <form method="POST" action="recebe.php">
        <div class="dados">
            <h2>Informe seus dados</h2>
            <ul>
                <li>Nome: <input type="text" name="nome" size="45" maxlength="40" minlength="3"></li>
                <li>Celular: <input type="text" name="nome" size="45" maxlength="15" minlength="8"></li>
                <li>Endereço: <input type="text" name="nome" size="45" maxlength="40" minlength="10"></li>
            <br>
            </ul>
        </div>
        <div class="secs">
            <img class="amos" src="media/consoles.webp" width="400px" height="250px">
            <div class="ped1">
            <h2>Dados do Pedido</h2>
            <ul>
                <li>Escolha o 1º produto:
                    <select name="codp1" >
                        <option value="1" >
                            PlayStation 5 - R$ 4.699,00
                        </option>
                        <option value="2" >
                            Xbox Series X - R$ 4.599,00
                        </Option>
                        <option value="3" >
                            Nintendo Switch - R$ 2.799,00   
                        </Option>
                        <option value="4" >
                            PlayStation 4 - R$ 2.299,00    
                        </Option>
                        <option value="5" >
                            Xbox One S - a partir de R$ 1.799,00    
                        </Option>
                    </select>
                </li>
                <li>Quantidade:
                    <input type="radio" name="qtd1" value="1"> 0
                    <input type="radio" name="qtd1" value="1"> 1
                    <input type="radio" name="qtd1" value="2"> 2
                    <input type="radio" name="qtd1" value="3"> 3
                    <input type="radio" name="qtd1" value="3"> 4
                    <input type="radio" name="qtd1" value="3"> 5
                </li>
            </ul>
            <ul>
                <li>Escolha o 2º produto:
                    <select name="codp2" >
                        <option value="1" >
                        </option>
                        <option value="2" >
                            Samsung QN90A Neo QLED 4K TV - R$ 9.899,95
                        </Option>
                        <option value="3" >
                            LG CX OLED 4K TV - R$ 9.899,95    
                        </Option>
                        <option value="4" >
                            Sony X90J BRAVIA 4K TV - R$ 6.599,95     
                        </Option>
                        <option value="5" >
                            TCL 6-Series 4K TV - R$ 3.849,95  
                        </Option>
                    </select>
                </li>
                <li>Quantidade:
                    <input type="radio" name="qtd2" value="1"> 0
                    <input type="radio" name="qtd2" value="1"> 1
                    <input type="radio" name="qtd2" value="2"> 2
                    <input type="radio" name="qtd2" value="3"> 3
                    <input type="radio" name="qtd2" value="3"> 4
                    <input type="radio" name="qtd2" value="3"> 5
                </li>
            </ul>
            <hr>
            <img class="amos" src="media/aces.jpg" width="400px" height="250px">
            <div class="ped2">
                <h2>Escolha outros produtos</h2>
                <ul>
                <li>Escolha o 3º produto:
                    <select name="codp3" >
                        <option value="1" >                    
                        </option>
                        <option value="2" >
                            microfone
                        </Option>
                        <option value="3" >
                            headset   
                        </Option>
                        <option value="4" >
                            web cam    
                        </Option>
                        <option value="5" >
                            fone
                        </Option>
                    </select>
                    Quantidade:
                    <input type="radio" name="qtd3" value="1"> 0
                    <input type="radio" name="qtd3" value="1"> 1
                    <input type="radio" name="qtd3" value="2"> 2
                    <input type="radio" name="qtd3" value="3"> 3
                    <input type="radio" name="qtd3" value="3"> 4
                    <input type="radio" name="qtd3" value="3"> 5
                </li>
                <li>
                    Escolha o 4º produto:
                    <select name="codp4" >
                        <option value="1" >                  
                        </option>
                        <option value="2" >
                            microfone
                        </Option>
                        <option value="3" >
                            headset   
                        </Option>
                        <option value="4" >
                         web cam    
                        </Option>
                        <option value="5" >
                            fone
                        </Option>
                    </select>
                    Quantidade: 
                    <input type="radio" name="qtd4" value="1"> 0
                    <input type="radio" name="qtd4" value="1"> 1
                    <input type="radio" name="qtd4" value="2"> 2
                    <input type="radio" name="qtd4" value="3"> 3
                    <input type="radio" name="qtd4" value="3"> 4
                    <input type="radio" name="qtd4" value="3"> 5
                </li>
                <li>
                    Escolha o 5º produto:
                    <select name="codp5" >
                        <option value="1" >                 
                        </option>
                        <option value="2" >
                            Microfone
                        </Option>
                        <option value="3" >
                            Headset   
                        </Option>
                        <option value="4" >
                            Web cam    
                        </Option>
                        <option value="5" >
                            Fone 
                        </Option>
                    </select>
                    Quantidade:
                    <input type="radio" name="qtd5" value="1"> 0
                    <input type="radio" name="qtd5" value="1"> 1
                    <input type="radio" name="qtd5" value="2"> 2
                    <input type="radio" name="qtd5" value="3"> 3
                    <input type="radio" name="qtd5" value="3"> 4
                    <input type="radio" name="qtd5" value="3"> 5
                </li>
                </ul>
            </div>
            </br>
            <div>
                Escolha a forma de pagamento que desejar:</br>
                <select name="pag" >
                    <option value="1" > &nbsp;&nbsp;&nbsp;  </Option>
                    <option value="2" > &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dinheiro </Option>
                    <option value="3" > &nbsp;&nbsp;&nbsp;&nbsp;Cartão de Crédito      </Option>
                    <option value="4" > &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cartão de Débito       </Option>
                </select>
                <h1>Entrega</h1>       
                <input type="radio" name="Entre" value="1"> Retirar na loja </br>
                <input type="radio" name="Entre" value="2"> Entregar</br>       
                <input type="submit" value="Confirma Pedido">
                <input type="reset"  value="Cancela Pedido">
            </div>
        </div>
    </form>
</div>
</div>
</body>
</html>