<?php
	
	$codp1 = $_POST["codp1"];

	if ($codp1 == 1){
		$p1="Playstation 5";
		$preco1=4699;
	}
	elseif ($codp1 == 2){
		$p1="Xbox series x";
		$preco1=4599;
	}
	elseif ($codp1 == 3){
		$p1="Nintendo Switch";
		$preco1=2799;
	}
	elseif ($codp1 == 4){
		$p1="Playstation 4";
		$preco1=2299;
	}	
	else{
		$p1="Xbox one s";
		$preco1=1799;
	}


	$qtd1=$_POST["qtd1"];
	$sub1 = $preco1 * $qtd1;

	
	$codp2=$_POST["codp2"];
	if ($codp2 == 1){
		$p2="Não escolheu nenhum produto";
		$preco2=0;
	}
	elseif ($codp2 == 2){
		$p2="Samsung QN90A Neo QLED 4K TV";
		$preco2=9899.95;
	}
	elseif ($codp2 == 3){
		$p2="LG CX OLED 4K TV ";
		$preco2=9899.95 ;
	}
	elseif ($codp2 == 4){
		$p2="Sony X90J BRAVIA 4K TV";
		$preco2=6599.95;
	}	
	else{
		$p2="TCL 6-Series 4K TV";
		$preco2=3849.95;
	}

	$qtd2=$_POST["qtd2"];
	$sub2 = $preco2 * $qtd2;


	$codp3=$_POST["codp3"];
	if ($codp3 == 1){
		$p3="Não escolheu nenhum produto";
		$preco3=0;
	}
	elseif ($codp3 == 2){
		$p3="microfone";
		$preco3=100;
	}
	elseif ($codp3 == 3){
		$p3="headset";
		$preco3=170;
	}
	elseif ($codp3 == 4){
		$p3="webcam";
		$preco3=120;
	}	
	else{
		$p3="fone";
		$preco3=70;
	}

	$qtd3=$_POST["qtd3"];
	$sub3 = $preco3 * $qtd3;


	$codp4=$_POST["codp4"];
	if ($codp4 == 1){
		$p4="Não escolheu nenhum produto";
		$preco4=0;
	}
	elseif ($codp4 == 2){
		$p4="microfone";
		$preco4=100;
	}
	elseif ($codp4 == 3){
		$p4="headset";
		$preco4=170;
	}
	elseif ($codp4 == 4){
		$p4="webcam";
		$preco4=120;
	}	
	else{
		$p4="fone";
		$preco4=70;
	}


	$qtd4=$_POST["qtd4"];
	$sub4 = $preco4 * $qtd4;	


	$codp5=$_POST["codp5"];
	if ($codp5 == 1){
		$p5="Não escolheu nenhum produto";
		$preco5=0;
	}
	elseif ($codp5 == 2){
		$p5="microfone";
		$preco5=100;
	}
	elseif ($codp5 == 3){
		$p5="headset";
		$preco5=170;
	}
	elseif ($codp5 == 4){
		$p5="webcam";
		$preco5=120;
	}	
	else{
		$p5="fone";
		$preco3=70;
	}


	$qtd5=$_POST["qtd5"];
	$sub5 = $preco5 * $qtd5;

	$total = $sub1 + $sub2 + $sub3 + $sub4 + $sub5;

	$pag=$_POST["pag"];
	if($pag==1){
		$fpag="pedido cancelado";
	}
	elseif($pag==2){
		$fpag="Dinhheiro";
	}
	elseif($pag==3){
		$fpag=" Cartão de Credito";
	}
	elseif($pag==4){
		$fpag="Cartão de Debito";
	}

	
	echo "o produto 1 escolhido foi $p1<br />";
	echo "O valor do produto $preco1<br />";
	echo "A quantidade pedida foi $qtd1<br />";
	echo "Subtotal: $sub1 <br /><br />";

	echo "o produto 2 escolhido foi $p2<br />";
	echo "O valor do produto $preco2<br />";
	echo "A quantidade pedida foi $qtd2<br />";
	echo "Subtotal: $sub2 <br /><br />";

	echo "o produto 3 escolhido foi $p3<br />";
	echo "O valor do produto $preco3<br />";
	echo "A quantidade pedida foi $qtd3<br />";
	echo "Subtotal: $sub3 <br /><br />";

	echo "o produto 4 escolhido foi $p4<br />";
	echo "O valor do produto $preco4<br />";
	echo "A quantidade pedida foi $qtd4<br />";
	echo "Subtotal: $sub4 <br /><br />";

	echo "o produto 5 escolhido foi $p5<br />";
	echo "O valor do produto $preco5<br />";
	echo "A quantidade pedida foi $qtd5<br />";
	echo "Subtotal: $sub5 <br /><br />";	

	echo "Valor a pagar: $total";
?>